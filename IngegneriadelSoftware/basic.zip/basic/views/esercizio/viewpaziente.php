<?php

use yii\helpers\Html;
use yii\widgets\DetailView;
use kartik\rating\StarRating;
use yii\bootstrap4\ActiveForm;

/* @var $this yii\web\View */
/* @var $model app\models\Esercizio */

$this->params['breadcrumbs'][] = ['label' => 'Esercizio', 'url' => ['index']];
?>
<div class="esercizio-view">

    <h1><?= Html::encode($this->title) ?></h1>

    <?= DetailView::widget([
        'model' => $model,
        'attributes' => [
            'Id',
			'indice',
        ],
    ]) ?>
	
	<p>
	<?php echo Html::a('Download', ['download','Id'=>$model->Id], ['class'=>'btn btn-primary']); ?>
	
	<?= Html::a('Carica esercizio svolto', ['upload2','Id'=> $model->Id], ['class' => 'btn btn-success']) ?>
	
	<?= Html::a('Salta Esercizio', ['salta','Id'=>$model->Id], ['class' => 'btn btn-danger']) ?>
	
	<?php $form = ActiveForm::begin(['id' => 'form']); ?>

	<?= $form->field($model, 'indice')->widget(StarRating::classname(),[
    'pluginOptions' => [
        'stars' => 5, 
        'min' => 0,
        'max' => 5,
        'step' => 1,
        'symbol' => html_entity_decode('&#xe005;', ENT_QUOTES, "utf-8"),
        'defaultCaption' => '{rating}',
    ]
	]);
	?>
	
		<div class="form-group">		
				<?= Html::submitButton('Valuta l\'esercizio ', ['class' => 'btn btn-primary']) ?>
		</div>
	
	<?php ActiveForm::end(); ?>
	</p>
	

</div>
