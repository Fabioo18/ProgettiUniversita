<?php

namespace app\controllers;

use app\models\Eserciziogruppo;
use app\models\EserciziogruppoSearch;
use app\models\EserciziogruppoSearch2;
use app\models\NoteserciziogruppoSearch;
use app\models\Noteserciziogruppo;
use app\models\Paziente;
use yii\web\Controller;
use yii\db\Query;
use yii\web\NotFoundHttpException;
use yii\filters\VerbFilter;
use yii\web\UploadedFile;


/**
 * EserciziogruppoController implements the CRUD actions for Eserciziogruppo model.
 */
class EserciziogruppoController extends Controller
{
    /**
     * @inheritDoc
     */
    public function behaviors()
    {
        return array_merge(
            parent::behaviors(),
            [
                'verbs' => [
                    'class' => VerbFilter::className(),
                    'actions' => [
                        'delete' => ['POST'],
                    ],
                ],
            ]
        );
    }

    /**
     * Lists all Eserciziogruppo models.
     *
     * @return string
     */
    public function actionIndex()
    {
		
        $searchModel = new EserciziogruppoSearch();
        $dataProvider = $searchModel->search($this->request->queryParams);

        return $this->render('index', [
            'searchModel' => $searchModel,
            'dataProvider' => $dataProvider,
        ]);
    }
	
	public function actionIndexpaziente()
    {
        $searchModel = new EserciziogruppoSearch2();
        $dataProvider = $searchModel->search($this->request->queryParams);

        return $this->render('indexpaziente', [
            'searchModel' => $searchModel,
            'dataProvider' => $dataProvider,
        ]);
    }
	
	
	public function actionNote($Id)
    {
		
		$searchModel = new NoteserciziogruppoSearch();
        $dataProvider = $searchModel->search($this->request->queryParams);
		$dataProvider->query->andWhere(['Id_es' => $Id]);

        return $this->render('note', [
            'searchModel' => $searchModel,
            'dataProvider' => $dataProvider,
        ]);
    }

	public function actionDownload($Id)
	{
		$model = $this->findModel($Id);
		return \Yii::$app->response->sendFile('uploads/gruppi/'.$model->nome_file);
	}
	
	public function actionDownload2($Id)
	{
		$model = Noteserciziogruppo::find()->where(['Id_es' => $Id])->one();
		return \Yii::$app->response->sendFile('uploads/gruppi/'.$model->nome_file);
	}

	public function actionUpload()
    {
		$model = new Eserciziogruppo();
			
        if (\Yii::$app->request->isPost && $model->load($this->request->post())) 
        {
            $model->files = UploadedFile::getInstance($model, 'files');

            if ($model->upload()) 
            {
				$rows = Paziente::find()
				->join('INNER JOIN','gruppo', 'gruppo.Id = paziente.id_gruppo')
				->groupBy(['gruppo.Id'])
				->all();

				foreach ($rows as $row) 
				{
					$note = new Noteserciziogruppo();
					$note->Id_es = $model->Id;
					$note->cf_paz = $row->cf;
					$note->save(false);
				}
				
                return $this->redirect(['view', 'Id' => $model->Id]);
            }
        }

		return $this->render('upload', ['model' => $model]);
    }
	
	public function actionUpload2($Id)
    {
		$query2 = new Query();
		$query2->select('paziente.cf')->from('paziente')->where(['paziente.id' => \Yii::$app->user->getId()])->all();
		$model = Noteserciziogruppo::find()->where(['noteserciziogruppo.Id_es' => $Id])->andWhere(['noteserciziogruppo.cf_paz' => $query2])->One();
		
        if (\Yii::$app->request->isPost && $model->load($this->request->post())) 
        {
            $model->files = UploadedFile::getInstance($model, 'files');

            if ($model->upload2()) 
            {
                return $this->redirect(['indexpaziente']);
            }
        }

		return $this->render('upload2', ['model' => $model]);
    }
	
	public function actionSalta($Id)
	{
		$model = $this->findModel($Id);
		
		$query2 = new Query();
		$query2->select('paziente.cf')->from('paziente')->where(['paziente.id' => \Yii::$app->user->getId()])->all();
        $query = Noteserciziogruppo::find()
		->join('INNER JOIN','eserciziogruppo', 'eserciziogruppo.Id = noteserciziogruppo.Id_es')
		->join('INNER JOIN','paziente', 'paziente.cf = noteserciziogruppo.cf_paz')
		->andWhere(['eserciziogruppo.Id' => $Id])
		->andWhere(['paziente.cf' => $query2])
		->one();
		
		if($query->svolto === 'Sì')
		{
			\Yii::$app->session->setFlash('error', "Impossibile saltare un esercizio già svolto.");
			return $this->redirect('indexpaziente');	
		}
		else
		{
			$query->saltato = 'Sì';
			$query->save(false);
			\Yii::$app->session->setFlash('success', "Esercizio saltato con successo.");
			return $this->redirect('indexpaziente');
				
		}
		
	}
	
    /**
     * Displays a single Eserciziogruppo model.
     * @param int $Id ID
     * @return string
     * @throws NotFoundHttpException if the model cannot be found
     */
    public function actionView($Id)
    {		
        return $this->render('view', [
            'model' => $this->findModel($Id),
        ]);
    }

	public function actionViewpaziente($Id)
    {
		$model = $this->findModel($Id);
		
		$query = new Query();
		$query->select('paziente.cf')->from('paziente')->where(['paziente.id' => \Yii::$app->user->getId()])->all();
		
        $note = Noteserciziogruppo::find()
		->join('INNER JOIN','eserciziogruppo', 'eserciziogruppo.Id = noteserciziogruppo.Id_es')
		->join('INNER JOIN','paziente', 'paziente.cf = noteserciziogruppo.cf_paz')
		->andWhere(['paziente.cf' => $query])
		->one();
		
		if ($this->request->isPost) 
		{
            if ($note->load($this->request->post()) && $note->save()) 
			{
                return $this->redirect(['viewpaziente', 'Id' => $model->Id]);
            }
        } 
        return $this->render('viewpaziente', ['model' => $model,'note' => $note]);
		
		
    }
    /**
     * Creates a new Eserciziogruppo model.
     * If creation is successful, the browser will be redirected to the 'view' page.
     * @return string|\yii\web\Response
     */
    public function actionCreate()
    {
        $model = new Eserciziogruppo();
		
        if ($this->request->isPost) {
			
            if ($model->load($this->request->post()) && $model->save()) 
			{
                return $this->redirect(['view', 'Id' => $model->Id]);
            }
        } 
		else 
		{
            $model->loadDefaultValues();
        }

        return $this->render('create', [
            'model' => $model,
        ]);
    }

    /**
     * Updates an existing Eserciziogruppo model.
     * If update is successful, the browser will be redirected to the 'view' page.
     * @param int $Id ID
     * @return string|\yii\web\Response
     * @throws NotFoundHttpException if the model cannot be found
     */
    public function actionUpdate($Id)
    {
        $model = $this->findModel($Id);

        if ($this->request->isPost && $model->load($this->request->post()) && $model->save()) {
            return $this->redirect(['view', 'Id' => $model->Id]);
        }

        return $this->render('update', [
            'model' => $model,
        ]);
    }

    /**
     * Deletes an existing Eserciziogruppo model.
     * If deletion is successful, the browser will be redirected to the 'index' page.
     * @param int $Id ID
     * @return \yii\web\Response
     * @throws NotFoundHttpException if the model cannot be found
     */
	
	public function actionDelete($Id)
    {
        $model = $this->findModel($Id);
		
		$query2 = new Query();
		$query2->select('eserciziogruppo.Id')->from('eserciziogruppo')
		->join('INNER JOIN','terapiagruppo', 'terapiagruppo.Id = eserciziogruppo.Id_terapiagruppo')
		->join('INNER JOIN','logopedista', 'logopedista.cf = terapiagruppo.cf_logo')
		->andWhere(['logopedista.id' => \Yii::$app->user->getId()])
		->andWhere(['eserciziogruppo.Id' => $Id]);
        $query = Noteserciziogruppo::find()->where(['Id_es' => $query2])->all();
		
		/*if($model->nome_file2 !== null)
		{
			unlink(\Yii::$app->basePath . '\web\uploads\gruppi/'.$model->nome_file2);
		}*/

		foreach ($query as $row) 
		{
			$row->delete();
		}
		
		$model->delete();
		unlink(\Yii::$app->basePath . '\web\uploads\gruppi/'.$model->nome_file);

        return $this->redirect(['index']);
    }

    /**
     * Finds the Eserciziogruppo model based on its primary key value.
     * If the model is not found, a 404 HTTP exception will be thrown.
     * @param int $Id ID
     * @return Eserciziogruppo the loaded model
     * @throws NotFoundHttpException if the model cannot be found
     */
    protected function findModel($Id)
    {
        if (($model = Eserciziogruppo::findOne(['Id' => $Id])) !== null) {
            return $model;
        }

        throw new NotFoundHttpException('The requested page does not exist.');
    }
}
