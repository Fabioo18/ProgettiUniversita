<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "prenotazione".
 *
 * @property int $Id
 * @property int|null $Id_appuntamento
 * @property string $dat
 * @property string $cf_logo
 * @property string $cf_care
 *
 * @property Appuntamento $appuntamento
 * @property Caregiver $cfCare
 * @property Logopedista $cfLogo
 */
class Prenotazione extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'prenotazione';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['Id_appuntamento'], 'integer'],
            [['dat', 'cf_logo', 'cf_care'], 'required'],
            [['dat'], 'safe'],
            [['dat', 'cf_logo', 'cf_care'], 'unique'],
            [['cf_logo'], 'exist', 'skipOnError' => true, 'targetClass' => Logopedista::className(), 'targetAttribute' => ['cf_logo' => 'cf']],
            [['cf_care'], 'exist', 'skipOnError' => true, 'targetClass' => Caregiver::className(), 'targetAttribute' => ['cf_care' => 'cf']],
            [['Id_appuntamento'], 'exist', 'skipOnError' => true, 'targetClass' => Appuntamento::className(), 'targetAttribute' => ['Id_appuntamento' => 'Id']],
        ];
    }

    /**
     * {@inheritdoc}
     */
   public function attributeLabels()
    {
        return [
            'Id' => 'ID',
            'dat' => 'Data',
            'cf_logo' => 'Codice fiscale Logopedista',
            'cf_care' => 'Codice fiscale Caregiver',
			'Id_appuntamento' => 'ID Appuntamento'
        ];
    }

    /**
     * Gets query for [[Appuntamento]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getAppuntamento()
    {
        return $this->hasOne(Appuntamento::className(), ['Id' => 'Id_appuntamento']);
    }

    /**
     * Gets query for [[CfCare]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getCfCare()
    {
        return $this->hasOne(Caregiver::className(), ['cf' => 'cf_care']);
    }

    /**
     * Gets query for [[CfLogo]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getCfLogo()
    {
        return $this->hasOne(Logopedista::className(), ['cf' => 'cf_logo']);
    }
}
