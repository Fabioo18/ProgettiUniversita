<?php

/** @var yii\web\View $this */
/** @var yii\bootstrap4\ActiveForm $form */
/** @var app\models\LoginForm $model */

use yii\bootstrap4\ActiveForm;
use yii\bootstrap4\Html;

$this->title = 'Registrazione';
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="site-signup">
    <h1><?= Html::encode($this->title) ?></h1>

    <p>Riempi il seguente modulo per effettuare la registrazione, grazie:</p>
	
	<?php
	if(Yii::$app->session->hasFlash('error'))
	{
	?>
		<div class="alert alert-error">
			<?php echo Yii::$app->session->getFlash('error');?>
		<div/>
	<?php
	}
	?>
	
	<div class="row">
	
		<div class = "col-lg-5">
	
			<?php $form = ActiveForm::begin(['id' => 'form-signup']); ?>

			<?= $form->field($model, 'username')?>

			<?= $form->field($model, 'rawPassword')->passwordInput()?>
			
			<?= $form->field($model, 'nome')?>
			
			<?= $form->field($model, 'cognome')?>
			
			<?= $form->field($model, 'codice_fiscale')?>
			
			<?= $form->field($model, 'email')?>
			
			<?= $form->field($model, 'categoria')->dropDownList([1 => 'Caregiver', 0 => 'Logopedista'],['prompt'=>'Scegli uno'])?>

			<div class="form-group">		
				<?= Html::submitButton('Registrati', ['class' => 'btn btn-primary', 'name' => 'signup-button']) ?>
			</div>
			
			<?php ActiveForm::end(); ?>
		</div>
	</div>
</div>