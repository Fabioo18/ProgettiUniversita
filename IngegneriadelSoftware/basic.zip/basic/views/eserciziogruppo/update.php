<?php

use yii\helpers\Html;

/* @var $this yii\web\View */
/* @var $model app\models\Eserciziogruppo */

$this->title = 'Aggiorna Esercizio di gruppo:';
$this->params['breadcrumbs'][] = ['label' => 'Esercizi di gruppo', 'url' => ['index']];
$this->params['breadcrumbs'][] = ['label' => $model->Id, 'url' => ['view', 'Id' => $model->Id]];
$this->params['breadcrumbs'][] = 'Aggiorna';
?>
<div class="eserciziogruppo-update">

    <h1><?= Html::encode($this->title) ?></h1>

    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>

</div>
