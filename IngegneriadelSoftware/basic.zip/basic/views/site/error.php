<?php

/** @var yii\web\View $this */
/** @var string $name */
/** @var string $message */
/** @var Exception$exception */

use yii\helpers\Html;

$this->title = $name;
?>
<div class="site-error">

    <h1><?= Html::encode($this->title) ?></h1>

    <div class="alert alert-danger">
        <?= nl2br(Html::encode($message)) ?>
    </div>

    <p>
        L'errore sovrastante è apparso mentre il server processava la sua richiesta.
    </p>
    <p>
       Contattaci se pensi che sia un errore del server. Grazie.
    </p>

</div>
