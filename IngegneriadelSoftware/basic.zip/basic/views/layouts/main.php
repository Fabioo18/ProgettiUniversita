<?php

/** @var yii\web\View $this */
/** @var string $content */

use app\assets\AppAsset;
use app\widgets\Alert;
use yii\bootstrap4\Breadcrumbs;
use yii\bootstrap4\Html;
use yii\bootstrap4\Nav;
use yii\bootstrap4\NavBar;
use app\Models\User;
use yii\db\Query;

AppAsset::register($this);
?>
<?php $this->beginPage() ?>
<!DOCTYPE html>
<html lang="<?= Yii::$app->language ?>" class="h-100">
<head>
    <meta charset="<?= Yii::$app->charset ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <?php $this->registerCsrfMetaTags() ?>
    <title><?= Html::encode($this->title) ?></title>
    <?php $this->head() ?>
</head>
<body class="d-flex flex-column h-100">
<?php $this->beginBody() ?>

<header>
	<div class="wrap">
	  <?php
		NavBar::begin([
			'brandLabel' => 'Logopedia System',
			'brandUrl' => Yii::$app->homeUrl,
			'options' => [
				'class' => 'navbar navbar-expand-md navbar-dark bg-dark fixed-top',
			],
		]);
		$menuItems = [
			['label' => 'Home', 'url' => ['/site/index']],
		];
		
		if (Yii::$app->user->getId())
		{
			if (Yii::$app->user->getIdentity()->categoria === '0') //Logopedista
			{		
				$menuItems[] = ['label' => 'Profilo', 'url' => ['/logopedista']];
				$menuItems[] = ['label' => 'Terapie', 'url' => ['/terapia']];
				$menuItems[] = ['label' => 'Terapie di Gruppo', 'url' => ['/terapiagruppo']];
				$menuItems[] = ['label' => 'Appuntamenti', 'url' => ['/appuntamento']];
				$menuItems[] = ['label' => 'Gruppi', 'url' => ['/gruppo']];
				$menuItems[] = ['label' => 'Chat', 'url' => ['/site/chat']];
			}
			
			if (Yii::$app->user->getIdentity()->categoria === '1') //Caregiver
			{
				$menuItems[] = ['label' => 'Profilo Caregiver', 'url' => ['/caregiver']];
				$menuItems[] = ['label' => 'Profilo Paziente', 'url' => ['/paziente']];
				$menuItems[] = ['label' => 'Questionario', 'url' => ['/site/questionario']];
				$menuItems[] = ['label' => 'Prenotazioni', 'url' => ['/prenotazione']];
				$menuItems[] = ['label' => 'Chat', 'url' => ['/site/chat']];
			}
			
			if (Yii::$app->user->getIdentity()->categoria === '2') //Paziente
			{	
				$menuItems[] = ['label' => 'Esercizi', 'url' => ['/esercizio/indexpaziente']];
				$query = new Query();
				$query->select('id_gruppo')->from('paziente')->where(['id' => Yii::$app->user->getId()])->one();
				
				if ($query != null)
				{
					$menuItems[] = ['label' => 'Esercizi di gruppo ', 'url' => ['/eserciziogruppo/indexpaziente']];
				}
				
			}
		}
		
		if (Yii::$app->user->isGuest)
		{
			$menuItems[] = ['label' => 'Registrati', 'url' => ['/site/registrazione']];
			$menuItems[] = ['label' => 'Login', 'url' => ['/site/login']];
		}
		else
		{
			$menuItems[] = '<li>'
			. Html::beginForm(['/site/logout'], 'post', ['class' => 'form-inline'])
			. Html::submitButton(
					'Logout (' . Yii::$app->user->identity->username . ')',
					['class' => 'btn btn-link logout']
			)
			. Html::endForm()
			. '</li>';	
		}
		
		echo Nav::widget([
        'options' => ['class' => 'navbar-nav'],
		'items' => $menuItems,
	]);
	
    NavBar::end();
    ?>
</header>

<main role="main" class="flex-shrink-0">
    <div class="container">
        <?= Breadcrumbs::widget([
            'links' => isset($this->params['breadcrumbs']) ? $this->params['breadcrumbs'] : [],
        ]) ?>
        <?= Alert::widget() ?>
        <?= $content ?>
    </div>
</main>

<footer class="footer mt-auto py-3 text-muted">
    <div class="container">
        <p class="float-left">&copy; Logopedia System <?= date('Y') ?></p>
    </div>
</footer>

<?php $this->endBody() ?>
</body>
</html>
<?php $this->endPage() ?>
