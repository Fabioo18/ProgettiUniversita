<?php

use yii\helpers\Html;

/* @var $this yii\web\View */
/* @var $model app\models\Prenotazione */

$this->title = 'Prenota';
$this->params['breadcrumbs'][] = ['label' => 'Prenotazione', 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="prenotazione-prenota">

    <?php
	if(Yii::$app->session->hasFlash('success'))
	{
	?>
		<div class="alert alert-success">
			<?php echo Yii::$app->session->getFlash('success');?>
		<div/>
	<?php
	}
	?>

</div>