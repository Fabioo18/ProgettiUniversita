<?php

/** @var yii\web\View $this */
/** @var yii\bootstrap4\ActiveForm $form */
/** @var app\models\ContactForm $model */

use yii\bootstrap4\ActiveForm;
use yii\bootstrap4\Html;
use yii\captcha\Captcha;

$this->params['breadcrumbs'][] = 'Questionario';
?>
<div class="site-contact">
    <h1><?= Html::encode($this->title) ?></h1>

	<?php
	if(Yii::$app->session->hasFlash('error'))
	{
		?>
			<div class = "alert alert-error">
				
			<div/>
		<?php
	}
    else if (Yii::$app->session->hasFlash('QuestionarioSubmitted'))
	{ ?>

        <div class="alert alert-success">
            Grazie per aver effettuato il questionario !.
        </div>

    <?php 
	}
	else
	{ ?>

        <h3>
            PLC Questionario del Linguaggio per i genitori
        </h3>

        <div class="questionario">
            <div class="col-lg-5">

                <?php $form = ActiveForm::begin(['id' => 'questionario']); ?>
					
					<?= $form->field($model, 'cf_paz')->textInput(['autofocus' => true]) ?>
					
                    <?= $form->field($model, 'd1')->radioList([
						1 => '1', 
						2 => '2',
						3 => '3',
						4 => '4',
					]); ?>
					
					<?= $form->field($model, 'd2')->radioList([
						1 => '1', 
						2 => '2',
						3 => '3',
						4 => '4',
					]); ?>
					
					<?= $form->field($model, 'd3')->radioList([
						1 => '1', 
						2 => '2',
						3 => '3',
						4 => '4',
					]); ?>
					
					<?= $form->field($model, 'd4')->radioList([
						True => 'Sì', 
						False => 'No',
					]); ?>
					
					<?= $form->field($model, 'd5')->radioList([
						True => 'Sì', 
						False => 'No',
					]); ?>
					
					<?= $form->field($model, 'd6')->radioList([
						True => 'Sì', 
						False => 'No',
					]); ?>

                    <?= $form->field($model, 'body')->textarea(['rows' => 6]) ?>


                    <div class="form-group">
                        <?= Html::submitButton('Inoltra', ['class' => 'btn btn-primary', 'name' => 'questionario-bottone']) ?>
                    </div>

                <?php ActiveForm::end(); ?>

            </div>
        </div>

    <?php } ?>
</div>
