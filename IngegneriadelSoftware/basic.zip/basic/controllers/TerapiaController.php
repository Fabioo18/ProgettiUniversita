<?php

namespace app\controllers;

use app\models\Terapia;
use app\models\TerapiaSearch;
use app\models\Questionario;
use app\models\QuestionarioSearch;
use yii\web\Controller;
use yii\web\NotFoundHttpException;
use yii\filters\VerbFilter;
use yii\db\Query;


/**
 * TerapiaController implements the CRUD actions for Terapia model.
 */
class TerapiaController extends Controller
{
    /**
     * @inheritDoc
     */
    public function behaviors()
    {
        return array_merge(
            parent::behaviors(),
            [
                'verbs' => [
                    'class' => VerbFilter::className(),
                    'actions' => [
                        'delete' => ['POST'],
                    ],
                ],
            ]
        );
    }

    /**
     * Lists all Terapia models.
     *
     * @return string
     */
    public function actionIndex()
    {	
        $searchModel = new TerapiaSearch();
        $dataProvider = $searchModel->search($this->request->queryParams);

        return $this->render('index', [
            'searchModel' => $searchModel,
            'dataProvider' => $dataProvider,
        ]);
    }

    /**
     * Displays a single Terapia model.
     * @param string $Id ID
     * @return string
     * @throws NotFoundHttpException if the model cannot be found
     */
    public function actionView($Id)
    {
		$questionario = new Questionario();
        return $this->render('view', [
            'model' => $this->findModel($Id),
			'questionario' => $questionario,
        ]);
    }
	
	public function actionViewcaregiver($cf)
    {
		$query = new Query();
		$query->select('id')->from('terapia')->where(['cf_paz' => $cf])->all();
		
		$questionario = new Questionario();
		
        return $this->render('viewcaregiver', [
            'model' => $this->findModel($query),
			'questionario' => $questionario,
        ]);
    }
	
	public function actionIndex_questionario($cf_care)
    {
		
		$questionario = Questionario::findOne($cf_care);
		
		if($questionario === null)
		{
			\Yii::$app->session->setFlash('error', "Questionario non presente.");
			 return $this->goBack();
		}
        return $this->render('index_questionario', [
            'model' => $questionario,
        ]);
    }

    /**
     * Creates a new Terapia model.
     * If creation is successful, the browser will be redirected to the 'view' page.
     * @return string|\yii\web\Response
     */
    public function actionCreate()
    {
        $model = new Terapia();
		
        if ($this->request->isPost) {
            if ($model->load($this->request->post()) && $model->save()) {
                return $this->redirect(['view', 'Id' => $model->Id]);
            }
        } else {
            $model->loadDefaultValues();
        }

        return $this->render('create', [
            'model' => $model,
        ]);
    }
	

    /**
     * Updates an existing Terapia model.
     * If update is successful, the browser will be redirected to the 'view' page.
     * @param string $Id ID
     * @return string|\yii\web\Response
     * @throws NotFoundHttpException if the model cannot be found
     */
    public function actionUpdate($Id)
    {
        $model = $this->findModel($Id);

        if ($this->request->isPost && $model->load($this->request->post()) && $model->save()) {
            return $this->redirect(['view', 'Id' => $model->Id]);
        }

        return $this->render('update', [
            'model' => $model,
        ]);
    }

    /**
     * Deletes an existing Terapia model.
     * If deletion is successful, the browser will be redirected to the 'index' page.
     * @param string $Id ID
     * @return \yii\web\Response
     * @throws NotFoundHttpException if the model cannot be found
     */
    public function actionDelete($Id)
    {
        $this->findModel($Id)->delete();

        return $this->redirect(['index']);
    }

    /**
     * Finds the Terapia model based on its primary key value.
     * If the model is not found, a 404 HTTP exception will be thrown.
     * @param string $Id ID
     * @return Terapia the loaded model
     * @throws NotFoundHttpException if the model cannot be found
     */
    protected function findModel($Id)
    {
        if (($model = Terapia::findOne(['Id' => $Id])) !== null) {
            return $model;
        }

        throw new NotFoundHttpException('The requested page does not exist.');
    }
}
