<?php

use yii\helpers\Html;
use app\models\User;

/* @var $this yii\web\View */
/* @var $model app\models\Paziente */

$this->title = 'Aggiorna i dati del Paziente';
$this->params['breadcrumbs'][] = ['label' => 'Paziente', 'url' => ['index']];
$this->params['breadcrumbs'][] = 'Aggiorna';
?>
<div class="paziente-update">

    <h1><?= Html::encode($this->title) ?></h1>

    <?= $this->render('_form', ['model' => $model,'user' => $user]) ?>

</div>
