<?php

use yii\helpers\Html;
use yii\widgets\DetailView;

/* @var $this yii\web\View */
/* @var $model app\models\Paziente */

$this->title = $model->cf;
$this->params['breadcrumbs'][] = ['label' => 'Paziente', 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
\yii\web\YiiAsset::register($this);
?>
<div class="paziente-view">

    <h1><?= Html::encode($this->title) ?></h1>

    <p>
        <?= Html::a('Aggiorna il profilo del paziente', ['update', 'cf' => $model->cf], ['class' => 'btn btn-primary']) ?>
		<?= Html::a('Visualizza la terapia del paziente', ['/terapia/viewcaregiver', 'cf' => $model->cf], ['class' => 'btn btn-primary']) ?>
        <?= Html::a('Elimina il profilo del paziente', ['delete', 'cf' => $model->cf], [
            'class' => 'btn btn-danger',
            'data' => [
                'confirm' => 'Sei sicuro di voler eliminare questo Paziente ?',
                'method' => 'post',
            ],
        ]) ?>
    </p>

    <?= DetailView::widget([
        'model' => $model,
        'attributes' => [
            'cf',
			'username',
            'cf_care',
            'nome',
            'cognome',
        ],
    ]) ?>

</div>
