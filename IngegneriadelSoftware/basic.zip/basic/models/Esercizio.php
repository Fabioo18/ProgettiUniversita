<?php

namespace app\models;

use Yii;
use yii\web\UploadedFile;

/**
 * This is the model class for table "esercizio".
 *
 * @property int $Id
 * @property int $Id_terapia
 * @property int|null $indice
 * @property string|null $nome
 * @property string|null $nome_file
 * @property string|null $nome_file2
 * @property string|null $svolto
 * @property string|null $saltato
 *
 * @property Paziente[] $cfPazs
 * @property Noteserciziogruppo[] $noteserciziogruppos
 * @property Terapia $terapia
 */
class Esercizio extends \yii\db\ActiveRecord
{
	public $files;
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'esercizio';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [       
            [['Id_terapia'], 'required'],
            [['Id_terapia'], 'integer'],
			[['Id_terapia', 'indice'], 'integer'],
            [['svolto', 'saltato'], 'string'],
			[['nome'], 'string', 'max' => 32],
            [['nome_file', 'nome_file2'], 'string', 'max' => 255],
            [['Id_terapia'], 'exist', 'skipOnError' => true, 'targetClass' => Terapia::className(), 'targetAttribute' => ['Id_terapia' => 'Id']],
			[['files'], 'file', 'skipOnEmpty' => true, 'extensions' => 'pdf'],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'Id' => 'ID',
            'Id_terapia' => 'Id Terapia',
			'indice' => 'Indice gradimento',
            'nome' => 'Nome Esercizio',
            'nome_file' => 'Nome File',
            'nome_file2' => 'Nome File Esercizio svolto',
            'svolto' => 'Svolto',
            'saltato' => 'Saltato',
			'files' => '',
        ];
    }

    /**
     * Gets query for [[Terapia]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getTerapia()
    {
        return $this->hasOne(Terapia::className(), ['Id' => 'Id_terapia']);
    }
	
	public function getNoteserciziogruppos()
    {
        return $this->hasMany(Noteserciziogruppo::className(), ['Id_es' => 'Id']);
    }
	
	public function getCfPazs()
    {
        return $this->hasMany(Paziente::className(), ['cf' => 'cf_paz'])->viaTable('noteserciziogruppo', ['Id_es' => 'Id']);
    }
	
	public function upload() 
    {	
        if(true) 
        {
            $this->files->saveAs('uploads/singolo/'. $this->files->baseName . '.' . $this->files->extension);
            //$this->image = $this->id . "." .$this->files->extension;
            $this->nome_file = $this->files->baseName. '.' . $this->files->extension;
            $this->save(false);
            return true;
        } 
        else 
        {
            return false;
        }
    }
	
	public function upload2() 
    {
        if(true) 
        {
            $this->files->saveAs('uploads/singolo/'. $this->files->baseName . '.' . $this->files->extension);
            //$this->image = $this->id . "." .$this->files->extension;
            $this->nome_file2 = $this->files->baseName. '.' . $this->files->extension;
			$this->svolto = 'Sì';
            $this->save(false);
            return true;
        } 
        else 
        {
            return false;
        }
    }
}
