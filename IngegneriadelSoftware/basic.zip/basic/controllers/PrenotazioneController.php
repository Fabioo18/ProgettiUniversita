<?php

namespace app\controllers;

use app\models\Prenotazione;
use app\models\PrenotazioneSearch;
use yii\web\Controller;
use yii\web\NotFoundHttpException;
use yii\filters\VerbFilter;
use app\models\Appuntamento;
use app\models\AppuntamentoSearch2;
use yii\db\query;
/**
 * PrenotazioneController implements the CRUD actions for Prenotazione model.
 */
class PrenotazioneController extends Controller
{
    /**
     * @inheritDoc
     */
    public function behaviors()
    {
        return array_merge(
            parent::behaviors(),
            [
                'verbs' => [
                    'class' => VerbFilter::className(),
                    'actions' => [
                        'delete' => ['POST'],
                    ],
                ],
            ]
        );
    }

    /**
     * Lists all Prenotazione models.
     *
     * @return string
     */
    public function actionIndex()
    {
        $searchModel = new PrenotazioneSearch();
        $dataProvider = $searchModel->search($this->request->queryParams);

        return $this->render('index', [
            'searchModel' => $searchModel,
            'dataProvider' => $dataProvider,
        ]);
    }

    /**
     * Displays a single Prenotazione model.
     * @param int $Id ID
     * @return string
     * @throws NotFoundHttpException if the model cannot be found
     */
    public function actionView($Id)
    {
        return $this->render('view', [
            'model' => $this->findModel($Id),
        ]);
    }

    /**
     * Creates a new Prenotazione model.
     * If creation is successful, the browser will be redirected to the 'view' page.
     * @return string|\yii\web\Response
     */
    public function actionCreate()
    {
       $searchModel = new AppuntamentoSearch2();
       $dataProvider = $searchModel->search($this->request->queryParams);
		
        return $this->render('create', [
			
            'searchModel' => $searchModel,
            'dataProvider' => $dataProvider,
        ]);		
    }
	
	public function actionPrenota($Id)
	{
		$searchModel = new AppuntamentoSearch2();
        $dataProvider = $searchModel->search($this->request->queryParams);
		$appuntamento = new Appuntamento();
		$appuntamento = Appuntamento::findOne($Id);
		$model = new Prenotazione();
		$model->dat = $appuntamento->dat;
		$model->cf_logo = $appuntamento->cf_logo;
		$query = new Query();
		$query->select('cf')->from('caregiver')->where(['id' => \Yii::$app->user->getId()])->one();
		$model->cf_care = $query;
		$model->Id_appuntamento = $appuntamento->Id;
		
		if ($appuntamento->prenotato == 'No')
		{
			$appuntamento->prenotato = 'Sì';
			if ($model->save())
			{
				$appuntamento->save();
				\Yii::$app->session->setFlash('success', "Prenotazione effettuata con successo.");
				return $this->render('/prenotazione/create', ['searchModel' => $searchModel,
				'dataProvider' => $dataProvider,]);
			}
			else
			{
				\Yii::$app->session->setFlash('error', "Prenotazione impossibile da effettuare, contattaci se pensi che ci sia un problema.");
			}
		}
		else
		{
			\Yii::$app->session->setFlash('error', "Appuntamento già prenotato.");
		}
		return $this->render('prenota', [
			'model' => $model,
        ]);
	}
	

    /**
     * Updates an existing Prenotazione model.
     * If update is successful, the browser will be redirected to the 'view' page.
     * @param int $Id ID
     * @return string|\yii\web\Response
     * @throws NotFoundHttpException if the model cannot be found
     */
    public function actionUpdate($Id)
    {
        $model = $this->findModel($Id);

        if ($this->request->isPost && $model->load($this->request->post()) && $model->save()) {
            return $this->redirect(['view', 'Id' => $model->Id]);
        }

        return $this->render('update', [
            'model' => $model,
        ]);
    }

    /**
     * Deletes an existing Prenotazione model.
     * If deletion is successful, the browser will be redirected to the 'index' page.
     * @param int $Id ID
     * @return \yii\web\Response
     * @throws NotFoundHttpException if the model cannot be found
     */
    public function actionDelete($Id)
    {
		$model = $this->findModel($Id);
		$appuntamento = new Appuntamento();
		$appuntamento = Appuntamento::findOne($model->Id_appuntamento);
		$appuntamento->prenotato = 'No';
		$appuntamento->save();
        $this->findModel($Id)->delete();
		

        return $this->redirect(['index']);
    }

    /**
     * Finds the Prenotazione model based on its primary key value.
     * If the model is not found, a 404 HTTP exception will be thrown.
     * @param int $Id ID
     * @return Prenotazione the loaded model
     * @throws NotFoundHttpException if the model cannot be found
     */
    protected function findModel($Id)
    {
        if (($model = Prenotazione::findOne(['Id' => $Id])) !== null) {
            return $model;
        }

        throw new NotFoundHttpException('The requested page does not exist.');
    }
}
