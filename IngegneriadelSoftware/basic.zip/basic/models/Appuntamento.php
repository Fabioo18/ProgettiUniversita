<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "appuntamento".
 *
 * @property int $Id
 * @property string $cf_logo
 * @property string $dat
 * @property string|null $note
 * @property string|null $prenotato
 *
 * @property Logopedista $cfLogo
 */
class Appuntamento extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'appuntamento';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['cf_logo', 'dat'], 'required'],
            [['dat'], 'safe'],
            [['prenotato'], 'string'],
            [['cf_logo'], 'string', 'max' => 16],
            [['note'], 'string', 'max' => 32],
            [['cf_logo'], 'exist', 'skipOnError' => true, 'targetClass' => Logopedista::className(), 'targetAttribute' => ['cf_logo' => 'cf']],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'Id' => 'ID',
            'cf_logo' => 'Cf Logo',
            'dat' => 'Dat',
            'note' => 'Note',
            'prenotato' => 'Prenotato',
        ];
    }

    /**
     * Gets query for [[CfLogo]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getCfLogo()
    {
        return $this->hasOne(Logopedista::className(), ['cf' => 'cf_logo']);
    }
}
