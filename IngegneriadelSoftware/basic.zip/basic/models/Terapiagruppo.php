<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "terapiagruppo".
 *
 * @property int $Id
 * @property string|null $cf_logo
 * @property int|null $Id_gruppo
 * @property string|null $note
 *
 * @property Logopedista $cfLogo
 * @property Gruppo $gruppo
 */
class Terapiagruppo extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'terapiagruppo';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['Id_gruppo'], 'integer'],
			[['Id_gruppo'], 'required'],
            [['cf_logo'], 'string', 'max' => 16],
            [['note'], 'string', 'max' => 255],
            [['cf_logo'], 'exist', 'skipOnError' => true, 'targetClass' => Logopedista::className(), 'targetAttribute' => ['cf_logo' => 'cf']],
            [['Id_gruppo'], 'exist', 'skipOnError' => true, 'targetClass' => Gruppo::className(), 'targetAttribute' => ['Id_gruppo' => 'Id']],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'Id' => 'ID',
            'cf_logo' => 'Cf Logo',
            'Id_gruppo' => 'Id Gruppo',
            'note' => 'Note',
        ];
    }

    /**
     * Gets query for [[CfLogo]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getCfLogo()
    {
        return $this->hasOne(Logopedista::className(), ['cf' => 'cf_logo']);
    }

    /**
     * Gets query for [[Gruppo]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getGruppo()
    {
        return $this->hasOne(Gruppo::className(), ['Id' => 'Id_gruppo']);
    }
}
