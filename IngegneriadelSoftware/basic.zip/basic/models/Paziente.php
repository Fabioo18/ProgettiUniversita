<?php

namespace app\models;

use Yii;
use yii\db\Query;

/**
 * This is the model class for table "paziente".
 *
 * @property string $cf
 * @property string|null $cf_care
 * @property int $id
 * @property string $nome
 * @property string $cognome
 *
 * @property Caregiver $cfCare
 * @property TblUser $id0
 * @property Terapia[] $terapias
 */
class Paziente extends \yii\db\ActiveRecord 
{
    /**
     * {@inheritdoc}
     */
	 public $username;
	public $password;
	 
    public static function tableName()
    {
        return 'paziente';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['cf', 'id', 'nome', 'cognome'], 'required'],
            [['id'], 'integer'],
            [['cf', 'cf_care'], 'string', 'max' => 16],
            [['nome', 'cognome'], 'string', 'max' => 32],
            [['cf'], 'unique'],
			[['cf_care'], 'unique'],
            [['id'], 'exist', 'skipOnError' => true, 'targetClass' => User::className(), 'targetAttribute' => ['id' => 'id']],
            [['cf_care'], 'exist', 'skipOnError' => true, 'targetClass' => Caregiver::className(), 'targetAttribute' => ['cf_care' => 'cf']],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'cf' => 'Codice fiscale Paziente',
            'cf_care' => 'Codice fiscale Caregiver',
            'id' => 'ID',
            'nome' => 'Nome',
            'cognome' => 'Cognome',
        ];
    }

    /**
     * Gets query for [[CfCare]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getCfCare()
    {
        return $this->hasOne(Caregiver::className(), ['cf' => 'cf_care']);
    }

    /**
     * Gets query for [[Id0]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getId0()
    {
        return $this->hasOne(User::className(), ['id' => 'id']);
    }

    /**
     * Gets query for [[Terapias]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getTerapias()
    {
        return $this->hasMany(Terapia::className(), ['cf_paz' => 'cf']);
    }
}
