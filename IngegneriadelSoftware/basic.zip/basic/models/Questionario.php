<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "questionario".
 *
 * @property string $cf_care
 * @property string|null $cf_paz
 * @property string $d1
 * @property string $d2
 * @property string $d3
 * @property int $d4
 * @property int $d5
 * @property int $d6
 * @property string|null $body
 *
 * @property Caregiver $cfCare
 * @property Paziente $cfPaz
 */
class Questionario extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'questionario';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['cf_care', 'cf_paz', 'd1', 'd2', 'd3', 'd4', 'd5', 'd6'], 'required'],
            [['d4', 'd5', 'd6'], 'integer'],
            [['cf_care', 'cf_paz'], 'string', 'max' => 16],
            [['d1', 'd2', 'd3'], 'string', 'max' => 1],
            [['body'], 'string', 'max' => 255],
            [['cf_care'], 'unique'],
			[['cf_paz'], 'unique'],
            [['cf_care'], 'exist', 'skipOnError' => true, 'targetClass' => Caregiver::className(), 'targetAttribute' => ['cf_care' => 'cf']],
            [['cf_paz'], 'exist', 'skipOnError' => true, 'targetClass' => Paziente::className(), 'targetAttribute' => ['cf_paz' => 'cf']],
        ];
    }

    /**
     * {@inheritdoc}
     */
     /**
     * {@inheritdoc}
     */
     public function attributeLabels()
    {
        return [
            'd1' => 'Quando il vostro bambino parla riuscite a capirlo ?',
			'd2' => 'Quando il vostro bambino parla viene capito dagli altri membri della famiglia ?',
			'd3' => 'Quando il vostro bambino parla viene capito da un\' altra persona che non è abituata al suo Linguaggio ?',
			'd4' => 'Il vostro bambino riesce a mettere insieme tre o più parole in modo significativo ?',
			'd5' => 'Il vostro bambino è capace di seguire una doppia istruzione (es. Prendi il cubetto, mettilo sul tavolo, ecc.) ?',
			'd6' => 'Il vostro bambino sa rispondere alle domande del tipo dove (es. Dov\'è il tuo orsacchiotto) ?',
			'body' => 'Specifica eventuali problematiche aggiuntive :',
			'cf_care' => 'Codice fiscale caregiver',
			'cf_paz' => 'Codice fiscale paziente'
        ];
    }

    /**
     * Gets query for [[CfCare]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getCfCare()
    {
        return $this->hasOne(Caregiver::className(), ['cf' => 'cf_care']);
    }

    /**
     * Gets query for [[CfPaz]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getCfPaz()
    {
        return $this->hasOne(Paziente::className(), ['cf' => 'cf_paz']);
    }
}
