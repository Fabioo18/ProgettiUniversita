<?php

use yii\helpers\Html;

/* @var $this yii\web\View */
/* @var $model app\models\Appuntamento */

$this->title = 'Inserisci Appuntamento';
$this->params['breadcrumbs'][] = ['label' => 'Appuntamento', 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="appuntamento-create">

    <h1><?= Html::encode($this->title) ?></h1>

    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>

</div>
