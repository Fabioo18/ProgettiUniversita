<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "eserciziogruppo".
 *
 * @property int $Id
 * @property int $Id_terapiagruppo
 * @property string|null $nome
 * @property int|null $indice_medio
 * @property string|null $nome_file
 *
 * @property Paziente[] $cfPazs
 * @property Noteserciziogruppo[] $noteserciziogruppos
 * @property Terapiagruppo $terapiagruppo
 */
class Eserciziogruppo extends \yii\db\ActiveRecord
{
	public $files;
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'eserciziogruppo';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['Id_terapiagruppo'], 'required'],
            [['Id_terapiagruppo', 'indice_medio'], 'integer'],
            [['nome'], 'string', 'max' => 32],
            [['nome_file'], 'string', 'max' => 255],
            [['Id_terapiagruppo'], 'exist', 'skipOnError' => true, 'targetClass' => Terapiagruppo::className(), 'targetAttribute' => ['Id_terapiagruppo' => 'Id']],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'Id' => 'ID',
            'Id_terapiagruppo' => 'Id Terapia di gruppo',
            'nome' => 'Nome',
            'nome_file' => 'Nome File',
            'indice_medio' => 'Indice Medio',
        ];
    }

    public function getCfPazs()
    {
        return $this->hasMany(Paziente::className(), ['cf' => 'cf_paz'])->viaTable('noteserciziogruppo', ['Id_es' => 'Id']);
    }

    /**
     * Gets query for [[Noteserciziogruppos]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getNoteserciziogruppos()
    {
        return $this->hasMany(Noteserciziogruppo::className(), ['Id_es' => 'Id']);
    }

    /**
     * Gets query for [[Terapiagruppo]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getTerapiagruppo()
    {
        return $this->hasOne(Terapiagruppo::className(), ['Id' => 'Id_terapiagruppo']);
    }
	
	public function upload() 
    {	
        if(true) 
        {
            $this->files->saveAs('uploads/gruppi/'. $this->files->baseName . '.' . $this->files->extension);
            $this->nome_file = $this->files->baseName. '.' . $this->files->extension;
            $this->save(false);
            return true;
        } 
        else 
        {
            return false;
        }
    }
	
	
}