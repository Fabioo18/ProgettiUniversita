<?php

use yii\helpers\Html;
use yii\widgets\DetailView;
use app\models\Questionario;

/* @var $this yii\web\View */
/* @var $model app\models\Terapia */

$this->title = $model->Id;
$this->params['breadcrumbs'][] = ['label' => 'Terapia', 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
\yii\web\YiiAsset::register($this);
?>
<div class="terapia-view">

    <h1><?= Html::encode($this->title) ?></h1>

    <p>
        <?= Html::a('Aggiorna', ['update', 'Id' => $model->Id], ['class' => 'btn btn-primary']) ?>
		<?= Html::a('Visualizza questionario', ['index_questionario','cf_care' => $model->cf_care], ['class' => 'btn btn-success']) ?>
		<?= Html::a('Inserisci Esercizio', ['/esercizio/upload'], ['class' => 'btn btn-primary']) ?>
		<?= Html::a('Visualizza Esercizi', ['/esercizio/index'], ['class' => 'btn btn-primary']) ?>
		<?= Html::a('Elimina', ['delete', 'Id' => $model->Id], [
            'class' => 'btn btn-danger',
            'data' => [
                'confirm' => 'Sei sicuro di voler eliminare questa terapia?',
                'method' => 'post',
            ],
        ]) ?>
    </p>

    <?= DetailView::widget([
        'model' => $model,
        'attributes' => [
            'Id',
            'cf_logo',
            'cf_care',
            'cf_paz',
            'note',
        ],
    ]) ?>

</div>
