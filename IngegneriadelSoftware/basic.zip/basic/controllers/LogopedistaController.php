<?php

namespace app\controllers;

use app\models\Logopedista;
use app\models\User;
use app\models\LogopedistaSearch;
use yii\web\Controller;
use yii\web\NotFoundHttpException;
use yii\filters\VerbFilter;
use yii\db\Query;
use app\Controllers\Yii;

/**
 * LogopedistaController implements the CRUD actions for Logopedista model.
 */
class LogopedistaController extends Controller
{
    /**
     * @inheritDoc
     */
    public function behaviors()
    {
        return array_merge(
            parent::behaviors(),
            [
                'verbs' => [
                    'class' => VerbFilter::className(),
                    'actions' => [
                        'delete' => ['POST'],
                    ],
                ],
            ]
        );
    }

    /**
     * Lists all Logopedista models.
     *
     * @return string
     
    public function actionIndex()
    {
		$query = new Query();
		$cf = $query->select('cf')->from('logopedista')->where(['id' => \Yii::$app->user->getId()])->all();
		$model = $this->findModel($cf);
        //$searchModel = new LogopedistaSearch();
		//$dataProvider = $model;
		//$searchModel->search($this->request->queryParams)
		
        return $this->render('index', ['model' => $model,]);//'searchModel' => $searchModel,'dataProvider' => $dataProvider,]);
    }
	*/
	
    /**
     * Displays a single Logopedista model.
     * @param string $cf Cf
     * @return string
     * @throws NotFoundHttpException if the model cannot be found
     */
    public function actionIndex()
    {
		$query = new Query();
		$cf = $query->select('cf')->from('logopedista')->where(['id' => \Yii::$app->user->getId()])->all();
		$model = $this->findModel($cf);
		$model->username = \Yii::$app->user->identity->username;
		
		return $this->render('index', ['model' => $model,]);
    }

    /**
     * Updates an existing Logopedista model.
     * If update is successful, the browser will be redirected to the 'view' page.
     * @param string $cf Cf
     * @return string|\yii\web\Response
     * @throws NotFoundHttpException if the model cannot be found
     */
    public function actionUpdate($cf)
    {
        $model = $this->findModel($cf);
		$user = User::findOne($model->id);
		$user->nome = 'a';
		$user->cognome = 'a';
		$user->email = 'a';
		$user->codice_fiscale = 'a';
		
        if ($this->request->isPost && $model->load($this->request->post()) && $model->save()) 
		{
			$user->setPassword($user->rawPassword);
			
			if ($this->request->isPost && $user->load($this->request->post()) && $user->validate()) 
			{
				$user->save(false);
				return $this->redirect(['index', 'cf' => $model->cf]);
			}
        }

        return $this->render('update', ['model' => $model, 'user' => $user]);
    }

    /**
     * Deletes an existing Logopedista model.
     * If deletion is successful, the browser will be redirected to the 'index' page.
     * @param string $cf Cf
     * @return \yii\web\Response
     * @throws NotFoundHttpException if the model cannot be found
     */
    public function actionDelete($cf)
    {
		$logo = $this->findModel($cf);
		$user = new User();
		$user = user::findOne($logo->id);
		$logo->delete();
		$user->delete();
		
        return $this->redirect(['site/registrazione']);
    }

    /**
     * Finds the Logopedista model based on its primary key value.
     * If the model is not found, a 404 HTTP exception will be thrown.
     * @param string $cf Cf
     * @return Logopedista the loaded model
     * @throws NotFoundHttpException if the model cannot be found
     */
    protected function findModel($cf)
    {
        if (($model = Logopedista::findOne(['cf' => $cf])) !== null) {
            return $model;
        }

        throw new NotFoundHttpException('The requested page does not exist.');
    }
	
}
