<?php

use yii\helpers\Html;
use yii\widgets\DetailView;

/* @var $this yii\web\View */
/* @var $model app\models\Eserciziogruppo */

$this->title = $model->Id;
$this->params['breadcrumbs'][] = ['label' => 'Esercizi di gruppo', 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
\yii\web\YiiAsset::register($this);
?>
<div class="eserciziogruppo-view">

    <h1><?= Html::encode($this->title) ?></h1>

    <p>
		<?= Html::a('Visualizza Esercizi singoli', ['note', 'Id' => $model->Id], ['class' => 'btn btn-success']) ?>
        <?= Html::a('Aggiorna', ['update', 'Id' => $model->Id], ['class' => 'btn btn-primary']) ?>
        <?= Html::a('Elimina', ['delete', 'Id' => $model->Id], [
            'class' => 'btn btn-danger',
            'data' => [
                'confirm' => 'Sei sicuro di voler eliminare questo esercizio di gruppo ?',
                'method' => 'post',
            ],
        ]) ?>
    </p>

    <?= DetailView::widget([
        'model' => $model,
        'attributes' => [
            'Id',
            'Id_terapiagruppo',
            'nome',
			'nome_file',
        ],
    ]) ?>

</div>
