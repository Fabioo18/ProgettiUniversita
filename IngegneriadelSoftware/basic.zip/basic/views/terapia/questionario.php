<?php

use yii\helpers\Html;
use yii\helpers\Url;
use yii\grid\ActionColumn;
use yii\grid\GridView;
use yii\widgets\Pjax;
/* @var $this yii\web\View */
/* @var $searchModel app\models\TerapiaSearch */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title = 'Questionario';
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="terapia-index">

    <h1><?= Html::encode($this->title) ?></h1>

    <?php Pjax::begin(); ?>
    <?php // echo $this->render('_search', ['model' => $searchModel]); ?>

    <?= GridView::widget([
        'dataProvider' => $dataProvider,
        'columns' => [
            ['class' => 'yii\grid\SerialColumn'],

            'cf_care',
            'cf_paz',
			'd1',
			'd2',
			'd3',
			'd4',
			'd5',
			'd6',
            [
                'class' => ActionColumn::className(),
                'urlCreator' => function ($action, app\models\Questionario $model, $key, $index, $column) {
                    return Url::toRoute([$action, 'cf_paz' => $model->cf_paz]);
                 }
            ],
        ],
    ]); ?>

    <?php Pjax::end(); ?>

</div>
