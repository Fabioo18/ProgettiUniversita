<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "noteserciziogruppo".
 *
 * @property int $Id_es
 * @property string $cf_paz
 * @property string|null $nome_file
 * @property string|null $svolto
 * @property string|null $saltato
 * @property int|null $indice
 *
 * @property Paziente $cfPaz
 * @property Esercizio $es
 */
class Noteserciziogruppo extends \yii\db\ActiveRecord
{
	public $files;
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'noteserciziogruppo';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['Id_es', 'cf_paz'], 'required'],
            [['Id_es', 'indice'], 'integer'],
            [['svolto', 'saltato'], 'string'],
            [['cf_paz'], 'string', 'max' => 16],
            [['nome_file'], 'string', 'max' => 255],
            [['Id_es', 'cf_paz'], 'unique', 'targetAttribute' => ['Id_es', 'cf_paz']],
            [['Id_es'], 'exist', 'skipOnError' => true, 'targetClass' => Esercizio::className(), 'targetAttribute' => ['Id_es' => 'Id']],
            [['cf_paz'], 'exist', 'skipOnError' => true, 'targetClass' => Paziente::className(), 'targetAttribute' => ['cf_paz' => 'cf']],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'Id_es' => 'Id Es',
            'cf_paz' => 'Cf Paz',
            'nome_file' => 'Nome File',
            'svolto' => 'Svolto',
            'saltato' => 'Saltato',
            'indice' => 'Indice',
        ];
    }

    /**
     * Gets query for [[CfPaz]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getCfPaz()
    {
        return $this->hasOne(Paziente::className(), ['cf' => 'cf_paz']);
    }

    /**
     * Gets query for [[Es]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getEs()
    {
        return $this->hasOne(Esercizio::className(), ['Id' => 'Id_es']);
    }
	
	public function upload2() 
    {
        if(true) 
        {
            $this->files->saveAs('uploads/gruppi/'. $this->files->baseName . '.' . $this->files->extension);
            $this->nome_file = $this->files->baseName. '.' . $this->files->extension;
			$this->svolto = 'Sì';
            $this->save(false);
            return true;
        } 
        else 
        {
            return false;
        }
    }
}
