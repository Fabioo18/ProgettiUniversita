<?php

use yii\helpers\Html;

/* @var $this yii\web\View */
/* @var $model app\models\Prenotazione */

$this->title = 'Prenota';
$this->params['breadcrumbs'][] = ['label' => 'Prenotazione', 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="prenotazione-create">

    <h1><?= Html::encode($this->title) ?></h1>

    <?= $this->render('/appuntamento/calendario',[
			
           'searchModel' => $searchModel,
            'dataProvider' => $dataProvider,
    ]) ?>

</div>
