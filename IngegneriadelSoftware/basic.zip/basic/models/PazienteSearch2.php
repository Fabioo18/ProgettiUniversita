<?php

namespace app\models;

use yii\base\Model;
use yii\db\Query;
use yii\data\ActiveDataProvider;
use app\models\Paziente;

/**
 * PazienteSearch2 represents the model behind the search form of `app\models\Paziente`.
 */
class PazienteSearch2 extends Paziente
{
    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['cf', 'cf_care', 'nome', 'cognome'], 'safe'],
            [['id'], 'integer'],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function scenarios()
    {
        // bypass scenarios() implementation in the parent class
        return Model::scenarios();
    }

    /**
     * Creates data provider instance with search query applied
     *
     * @param array $params
     *
     * @return ActiveDataProvider
     */
    public function search($params)
    {
		$query = Paziente::find()
           ->join('INNER JOIN','gruppo', 'gruppo.id = paziente.id_gruppo');
        // add conditions that should always apply here

        $dataProvider = new ActiveDataProvider([
            'query' => $query,	
        ]);

        $this->load($params);

        if (!$this->validate()) {
            // uncomment the following line if you do not want to return any records when validation fails
            // $query->where('0=1');
            return $dataProvider;
        }

        /*// grid filtering conditions
        $query->andFilterWhere([
           'id' => $this->id,
        ]);

        $query
             ->andFilterWhere(['like', 'cf', $this->cf])
            ->andFilterWhere(['like', 'cf_care', $this->cf_care])
            ->andFilterWhere(['like', 'nome', $this->nome])
            ->andFilterWhere(['like', 'cognome', $this->cognome]);
*/
        return $dataProvider;
    }
}