<?php

use yii\helpers\Html;
use yii\widgets\DetailView;

/* @var $this yii\web\View */
/* @var $model app\models\Caregiver */

$this->title = 'Profilo';
$this->params['breadcrumbs'][] = ['label' => 'Caregiver', 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
\yii\web\YiiAsset::register($this);
?>
<div class="caregiver-view">

    <h1><?= Html::encode($this->title) ?></h1>

    <p>
        <?= Html::a('Aggiorna il tuo profilo', ['update', 'cf' => $model->cf], ['class' => 'btn btn-primary']) ?>
        <?= Html::a('Elimina il tuo profilo', ['delete', 'cf' => $model->cf], [
            'class' => 'btn btn-danger',
            'data' => [
                'confirm' => 'Sei sicuro di voler eliminare il tuo account ?',
                'method' => 'post',
            ],
        ]) ?>
    </p>

    <?= DetailView::widget([
        'model' => $model,
        'attributes' => [
            'cf',
            'nome',
            'cognome',
			'username',
            'email:email',
        ],
    ]) ?>

</div>
