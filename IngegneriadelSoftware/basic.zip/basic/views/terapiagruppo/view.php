<?php

use yii\helpers\Html;
use yii\widgets\DetailView;

/* @var $this yii\web\View */
/* @var $model app\models\Terapiagruppo */

$this->title = $model->Id;
$this->params['breadcrumbs'][] = ['label' => 'Terapie di gruppo', 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
\yii\web\YiiAsset::register($this);
?>
<div class="terapiagruppo-view">

    <h1><?= Html::encode($this->title) ?></h1>

    <p>
        <?= Html::a('Aggiorna', ['update', 'Id' => $model->Id], ['class' => 'btn btn-primary']) ?>
		<?= Html::a('Inserisci Esercizio', ['/eserciziogruppo/upload'], ['class' => 'btn btn-primary']) ?>
		<?= Html::a('Visualizza Esercizi', ['/eserciziogruppo/index'], ['class' => 'btn btn-primary']) ?>
        <?= Html::a('Elimina', ['delete', 'Id' => $model->Id], [
            'class' => 'btn btn-danger',
            'data' => [
                'confirm' => 'Sei sicuro di voler eliminare questa terapia ?',
                'method' => 'post',
            ],
        ]) ?>
    </p>

    <?= DetailView::widget([
        'model' => $model,
        'attributes' => [
            'Id',
            'cf_logo',
            'Id_gruppo',
            'note',
        ],
    ]) ?>

</div>
