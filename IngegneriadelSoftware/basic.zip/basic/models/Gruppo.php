<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "gruppo".
 *
 * @property int $Id
 * @property string|null $note
 *
 * @property Paziente[] $paziente
 */
class Gruppo extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'gruppo';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['note'], 'string', 'max' => 32],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'Id' => 'ID',
            'note' => 'Note',
        ];
    }

    /**
     * Gets query for [[Paziente]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getPaziente()
    {
        return $this->hasMany(Paziente::className(), ['id_gruppo' => 'Id']);
    }
}
