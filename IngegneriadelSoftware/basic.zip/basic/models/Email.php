<?php

namespace app\models;

use Yii;
use yii\base\Model;
use yii\web\UploadedFile;

/**
 * LoginForm is the model behind the login form.
 *
 * @property-read User|null $user
 *
 */
class Email extends Model
{
	public $files;
    public $email;
	public $oggetto;
    public $testo;

    /**
     * @return array the validation rules.
     */
    public function rules()
    {
        return [
            [['email','testo','oggetto'], 'required'],
			['email', 'email'],
			[['testo'], 'string', 'max' => 255],
        ];
    }
	
	public function attributeLabels()
    {
        return [
            'email' => 'E-mail',
            'oggetto' => 'Oggetto',
			'testo' => 'Testo',
        ];
    }
}