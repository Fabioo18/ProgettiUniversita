<?php

use yii\helpers\Html;
use yii\helpers\Url;
use yii\grid\ActionColumn;
use yii\grid\GridView;
use yii\widgets\Pjax;
/* @var $this yii\web\View */
/* @var $searchModel app\models\TerapiaSearch */
/* @var $dataProvider yii\data\ActiveDataProvider */
/* @var $searchModel2 app\models\TerapiaSearch2 */
/* @var $dataProvider2 yii\data\ActiveDataProvider */

$this->title = 'Terapia';
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="terapia-index">

    <h1><?= Html::encode($this->title) ?></h1>

    <p>
        <?= Html::a('Inserisci Terapia', ['create'], ['class' => 'btn btn-success']) ?>
    </p>
	
    <?php Pjax::begin(); ?>
	
    <?= GridView::widget([
        'dataProvider' => $dataProvider,
        'filterModel' => $searchModel,
        'columns' => [
            ['class' => 'yii\grid\SerialColumn'],

            'Id',
            'cf_logo',
            'cf_care',
            'cf_paz',
            [
                'class' => ActionColumn::className(),
                'urlCreator' => function ($action, app\models\Terapia $model, $key, $index, $column) {
                    return Url::toRoute([$action, 'Id' => $model->Id]);
                 }
            ],
        ],
    ]); ?>

    <?php Pjax::end(); ?>

</div>
