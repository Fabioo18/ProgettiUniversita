<?php

namespace app\controllers;

use Yii;
use yii\filters\AccessControl;
use yii\web\Controller;
use yii\web\Response;
use yii\filters\VerbFilter;
use yii\web\UploadedFile;
use app\models\LoginForm;
use app\models\Email;
use app\models\User;
use app\models\Caregiver;
use app\models\Logopedista;
use app\models\Questionario;
use yii\db\Query;
use yii\validators\UniqueValidator;
use yii\db\conditions\ConjunctionCondition;

class SiteController extends Controller
{
    /**
     * {@inheritdoc}
     */
    public function behaviors()
    {
        return [
            'access' => [
                'class' => AccessControl::className(),
                'only' => ['logout'],
                'rules' => [
                    [
                        'actions' => ['logout'],
                        'allow' => true,
                        'roles' => ['@'],
                    ],
                ],
            ],
            'verbs' => [
                'class' => VerbFilter::className(),
                'actions' => [
                    'logout' => ['post'],
                ],
            ],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function actions()
    {
        return [
            'error' => [
                'class' => 'yii\web\ErrorAction',
            ],
            'captcha' => [
                'class' => 'yii\captcha\CaptchaAction',
                'fixedVerifyCode' => YII_ENV_TEST ? 'testme' : null,
            ],
        ];
    }

    /**
     * Displays homepage.
     *
     * @return string
     */
    public function actionIndex()
    {
        return $this->render('index');
    }

	public function actionChat()
	{
		$model = new Email();
		
		if(Yii::$app->user->getIdentity()->categoria === '1')//caregiver
		{
			$care = Caregiver::find()->where(['id' => (Yii::$app->user->getIdentity()->getId())])->one();
			if ($model->load(Yii::$app->request->post())) 
			{
			
				if($model->files !== null)
					{
						$model->files = UploadedFile::getInstance($model, 'files');
						$model->files->saveAs('uploads/allegati/'. $model->files->baseName . '.' . $model->files->extension);
						Yii::$app->mailer->compose()
						->setFrom($care->email)
						->setTo($model->email)
						->setSubject($model->oggetto)
						->setTextBody($model->testo)
						->attachContent('Attachment content', ['fileName' => $model->files, 'contentType' => 'text/plain'])
						->send();
						\Yii::$app->session->setFlash('success', "Mail inviata con successo.");
						return $this->redirect('index');
					}
					else
					{
						Yii::$app->mailer->compose()
						->setFrom($care->email)
						->setTo($model->email)
						->setSubject($model->oggetto)
						->setTextBody($model->testo)
						->send();
						\Yii::$app->session->setFlash('success', "Mail inviata con successo.");
						return $this->redirect('index');
					}
			}
		}
		else //logopedista
		{
			$logo = Logopedista::find()->where(['id' => (Yii::$app->user->getIdentity()->getId())])->one();
			
			if ($model->load(Yii::$app->request->post())) 
			{
				if($model->files !== null)
				{
					$model->files = UploadedFile::getInstance($model, 'files');
					$model->files->saveAs('uploads/allegati/'. $model->files->baseName . '.' . $model->files->extension);
					Yii::$app->mailer->compose()
					->setFrom($logo->email)
					->setTo($model->email)
					->setSubject($model->oggetto)
					->setTextBody($model->testo)
					->attachContent('Attachment content', ['fileName' => $model->files, 'contentType' => 'text/plain'])
					->send();
					\Yii::$app->session->setFlash('success', "Mail inviata con successo.");
					return $this->redirect('index');
				}
				else
				{
					Yii::$app->mailer->compose()
					->setFrom($logo->email)
					->setTo($model->email)
					->setSubject($model->oggetto)
					->setTextBody($model->testo)
					->send();
					\Yii::$app->session->setFlash('success', "Mail inviata con successo.");
					return $this->redirect('index');
				}
			}
		}
			
		return $this->render('chat',['model' => $model,]);
	}
    /**
     * Login action.
     *
     * @return Response|string
     */
	public function actionRegistrazione()
    {
        if (!Yii::$app->user->isGuest) {
            return $this->goHome();
        }

        $model = new User();

        if ($model->load(Yii::$app->request->post())) 
        {
            $model->setPassword($model->rawPassword);
            $model->generateAuthKey();

            if(!$model->validate())
            {
                return $this->render('registrazione', ['model' => $model,]);
            }
            else
            {
                if($model->categoria === '1')
                {
                    $caregiver = Yii::createObject([
                    'class' => 'app\Models\Caregiver',
                    'nome' => $model->nome,
                    'cognome' => $model->cognome,
                    'email' => $model->email,
                    'cf' => $model->codice_fiscale]);
					if($model->save())
					{
						$caregiver->id = $model->id;
						if($caregiver->save())
						{
							\Yii::$app->session->setFlash('success', "Registrazione effettuata con successo. Per favore effettua il login.");
							return $this->redirect(['site/login']);
						}
						else
						{
							\Yii::$app->session->setFlash('error', "Impossibile effettuare la registrazione codice fiscale o e-mail incorretti o già presenti.");
							$model->delete();
						}
					}                   
                }
                else
                {
                    $logopedista = Yii::createObject([
                    'class' => 'app\Models\Logopedista',
                    'id' => $model->id,
                    'nome' => $model->nome,
                    'cognome' => $model->cognome,
                    'email' => $model->email,
                    'cf' => $model->codice_fiscale]);
					if($model->save())
					{
						$logopedista->id = $model->id;
						if($logopedista->save())
						{
							\Yii::$app->session->setFlash('success', "Registrazione effettuata con successo. Per favore effettua il login.");
							return $this->redirect(['site/login']);
						}
						else
						{
							\Yii::$app->session->setFlash('error', "Impossibile effettuare la registrazione codice fiscale o e-mail incorretti o già presenti.");
							$model->delete();
						}
					}                      
                }          
            }
        }

        return $this->render('registrazione', ['model' => $model,]);
    }
	
   public function actionLogin()
    {
        if (!Yii::$app->user->isGuest) {
            return $this->goHome();
        }

        $model = new LoginForm();
		
        if ($model->load(Yii::$app->request->post()) && $model->login()) 
		{
			return $this->goBack();
        }

        return $this->render('login', ['model' => $model,]);
    }

    /**
     * Logout action.
     *
     * @return Response
     */
    public function actionLogout()
    {
        Yii::$app->user->logout();

        return $this->goHome();
    }

    /**
     * Displays contact page.
     *
     * @return Response|string
     */
	 public function actionQuestionario()
    {

        $model = new Questionario();
		$care = Caregiver::find()->where(['id' => (Yii::$app->user->getIdentity()->getId())])->one();
		$model->cf_care = $care->cf;
		
		if($model->load(Yii::$app->request->post()) && $model->save())
		{
			Yii::$app->session->setFlash('QuestionarioSubmitted');
            return $this->refresh();		
		}
		
        if ($model->load(Yii::$app->request->post()) && !$model->save()) 
		{  
			Yii::$app->session->setFlash('error', "è stato riscontrato un errore nel questionario, oppure ne hai già compilato uno, se pensi che ci sia un errore, contattaci !");
			return $this->refresh();
        }
	
       return $this->render('/site/questionario', ['model' => $model,]);
    }
	
}
