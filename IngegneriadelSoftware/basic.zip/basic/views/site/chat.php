<?php

/** @var yii\web\View $this */
/** @var yii\bootstrap4\ActiveForm $form */
/** @var app\models\LoginForm $model */

use yii\bootstrap4\ActiveForm;
use yii\bootstrap4\Html;

$this->title = 'Chat';
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="site-signup">
    <h1><?= Html::encode($this->title) ?></h1>

    <p>Inoltra la mail:</p>
	
	<div class="row">
	
		<div class = "col-lg-5">
	
			<?php $form = ActiveForm::begin(['id' => 'form-signup']); ?>

			<?= $form->field($model, 'email')?>
			
			<?= $form->field($model, 'oggetto')?>
			
			<?= $form->field($model, 'testo')->textArea(['rows' => 6])?>
			
			<?= $form->field($model, 'files')->fileInput(['multiple' => true,]) ?>

			<div class="form-group">		
				<?= Html::submitButton('Invia Email', ['class' => 'btn btn-primary']) ?>
			</div>
			
			<?php ActiveForm::end(); ?>
		</div>
	</div>
</div>