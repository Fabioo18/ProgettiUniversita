<?php

namespace app\models;

use yii\base\Model;
use yii\data\ActiveDataProvider;
use app\models\Noteserciziogruppo;
use yii\db\Query;

/**
 * NoteserciziogruppoSearch represents the model behind the search form of `app\models\Noteserciziogruppo`.
 */
class NoteserciziogruppoSearch extends Noteserciziogruppo
{
    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['Id_es'], 'integer'],
            [['cf_paz', 'svolto', 'saltato'], 'safe'],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function scenarios()
    {
        // bypass scenarios() implementation in the parent class
        return Model::scenarios();
    }

    /**
     * Creates data provider instance with search query applied
     *
     * @param array $params
     *
     * @return ActiveDataProvider
     */
    public function search($params)
    {
		$query2 = new Query();
		$query2->select('eserciziogruppo.Id')->from('eserciziogruppo')
		->join('INNER JOIN','terapiagruppo', 'terapiagruppo.Id = eserciziogruppo.Id_terapiagruppo')
		->join('INNER JOIN','logopedista', 'logopedista.cf = terapiagruppo.cf_logo')
		->andWhere(['logopedista.id' => \Yii::$app->user->getId()]);
		
        $query = Noteserciziogruppo::find()->where(['Id_es' => $query2]);

        // add conditions that should always apply here

        $dataProvider = new ActiveDataProvider([
            'query' => $query,
        ]);

        $this->load($params);

        if (!$this->validate()) {
            // uncomment the following line if you do not want to return any records when validation fails
            // $query->where('0=1');
            return $dataProvider;
        }

        // grid filtering conditions
        $query->andFilterWhere([
            'Id_es' => $this->Id_es,
        ]);

        $query->andFilterWhere(['like', 'cf_paz', $this->cf_paz])
            ->andFilterWhere(['like', 'svolto', $this->svolto])
            ->andFilterWhere(['like', 'saltato', $this->saltato]);

        return $dataProvider;
    }
}
