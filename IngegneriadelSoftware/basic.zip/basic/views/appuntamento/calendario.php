<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;
use yii\grid\GridView;
use \yii\widgets\Pjax;
use yii\helpers\Url;
use yii\grid\ActionColumn;
/* @var $this yii\web\View */
/* @var $model app\models\Appuntamento */
/* @var $form yii\widgets\ActiveForm */
?>

<div class="appuntamento-form">

  <?= GridView::widget([
        'dataProvider' => $dataProvider,
        'columns' => [
			
            'dat',
            'cf_logo',
            'note',
			
			[
            'class' => 'yii\grid\ActionColumn',
			'header'=>'Prenota',
			'template' => ' {myButton}',  
			'buttons' => [
                'myButton' => function($url, $model, $key)
				{     
                    return Html::a('Prenota', ['/prenotazione/prenota', 'Id' => $model->Id], ['class' => 'btn btn-primary']); 				
                }
            ]
			
			
			],
			
        
        ],
    ]); ?>
	

</div>


