<?php

namespace app\controllers;

use app\models\Paziente;
use app\models\PazienteSearch;
use yii\web\Controller;
use yii\web\NotFoundHttpException;
use yii\filters\VerbFilter;
use app\models\User;
use app\models\Caregiver;
use yii\data\ActiveDataProvider;
use yii\db\Query;
use app\models\Terapia;


/**
 * PazienteController implements the CRUD actions for Paziente model.
 */
class PazienteController extends Controller
{
    /**
     * @inheritDoc
     */
    public function behaviors()
    {
        return array_merge(
            parent::behaviors(),
            [
                'verbs' => [
                    'class' => VerbFilter::className(),
                    'actions' => [
                        'delete' => ['POST'],
                    ],
                ],
            ]
        );
    }

    /**
     * Lists all Paziente models.
     *
     * @return string
     */
    public function actionIndex()
    {
        $searchModel = new PazienteSearch();
        $dataProvider = $searchModel->search($this->request->queryParams);

        return $this->render('index', [
            'searchModel' => $searchModel,
            'dataProvider' => $dataProvider,
        ]);
    }

    /**
     * Displays a single Paziente model.
     * @param string $cf Cf
     * @return string
     * @throws NotFoundHttpException if the model cannot be found
     */
    public function actionView($cf)
    {
		$model = $this->findModel($cf);
		$user = User::findOne($model->id);
		$model->username = $user->username;

		
		return $this->render('view', [
			'model' => $model,
        ]);
    }

    /**
     * Creates a new Paziente model.
     * If creation is successful, the browser will be redirected to the 'view' page.
     * @return string|\yii\web\Response
     */
    public function actionCreate()
    {
		$user = new User();
		$user->email = 'a';	
		$user->categoria = 2;
		$model = new Paziente();
		
		

        if ($this->request->isPost) 
		{	
            if ($model->load($this->request->post()) && $user->load($this->request->post())) 
			{		
				$user->nome = $model->nome;
				$user->cognome = $model->cognome;
				$user->setPassword($user->rawPassword);
				
				if($model->cf_care === $model->cf)
				{
					\Yii::$app->session->setFlash('error', "Impossibile effettuare la registrazione del paziente codice fiscale identico a quello del caregiver.");
					return $this->redirect(['create', 'cf' => $model->cf]);
				}
				
				$query = new Query();
				$cf = $query->select('cf')->from('caregiver')->where(['id' => \Yii::$app->user->getId()])->all();
				
				/*
				if($model->cf_care !== $cf)
				{
					\Yii::$app->session->setFlash('error', "Impossibile effettuare la registrazione del paziente codice fiscale inserito non corrispondente.");
					return $this->redirect(['create', 'cf' => $model->cf]);
				}*/
				
				$user->codice_fiscale = $model->cf;
				$user->generateAuthKey();
						
				if($user->save())
				{
					$model->id = $user->id;
					
					if($model->save())
					{
						return $this->redirect(['view', 'cf' => $model->cf]);
					}
					else
					{
						$user->delete();
					}
				}   
            }
        } 

        return $this->render('create', ['model' => $model, 'user' => $user]);
    }

    /**
     * Updates an existing Paziente model.
     * If update is successful, the browser will be redirected to the 'view' page.
     * @param string $cf Cf
     * @return string|\yii\web\Response
     * @throws NotFoundHttpException if the model cannot be found
     */
    public function actionUpdate($cf)
    {
		$model = $this->findModel($cf);
		$user = User::findOne($model->id);
		$user->nome = 'a';
		$user->cognome = 'a';
		$user->email = 'a';
		$user->codice_fiscale = 'a';
		
        if ($this->request->isPost && $model->load($this->request->post())) 
		{
			if($model->cf_care === $model->cf)
			{
				\Yii::$app->session->setFlash('error', "Impossibile effettuare la registrazione del paziente codice fiscale identico a quello del caregiver.");
				return $this->render('update', ['model' => $model, 'user' => $user]);
			}
			
			$user->setPassword($user->rawPassword);
			
			if ($this->request->isPost && $user->load($this->request->post()) && $user->validate() && $model->save()) 
			{
				$user->save(false);
				return $this->redirect(['view', 'cf' => $model->cf]);
			}
        }

        return $this->render('update', ['model' => $model, 'user' => $user]);
		
    }

    /**
     * Deletes an existing Paziente model.
     * If deletion is successful, the browser will be redirected to the 'index' page.
     * @param string $cf Cf
     * @return \yii\web\Response
     * @throws NotFoundHttpException if the model cannot be found
     */
    public function actionDelete($cf)
    {
		$paz = $this->findModel($cf);
		$user = new User();
		$user = user::findOne($paz->id);
		$paz->delete();
		$user->delete();

        return $this->redirect(['index']);
    }

    /**
     * Finds the Paziente model based on its primary key value.
     * If the model is not found, a 404 HTTP exception will be thrown.
     * @param string $cf Cf
     * @return Paziente the loaded model
     * @throws NotFoundHttpException if the model cannot be found
     */
    protected function findModel($cf)
    {
        if (($model = Paziente::findOne(['cf' => $cf])) !== null) {
            return $model;
        }

        throw new NotFoundHttpException('The requested page does not exist.');
    }
}
