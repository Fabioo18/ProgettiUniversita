<?php

use yii\helpers\Html;
use yii\widgets\DetailView;
use yii\grid\GridView;
use yii\grid\ActionColumn;
use yii\helpers\Url;
use app\models\Paziente;

/* @var $this yii\web\View */
/* @var $model app\models\Gruppo */

$this->title = 'Gruppo '.$model->Id;
$this->params['breadcrumbs'][] = ['label' => 'Gruppo', 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
\yii\web\YiiAsset::register($this);
?>
<div class="gruppo-view">

    <h1><?= Html::encode($this->title) ?></h1>

    <p>
        <?= Html::a('Aggiorna', ['update', 'Id' => $model->Id], ['class' => 'btn btn-primary']) ?>
        <?= Html::a('Elimina', ['delete', 'Id' => $model->Id], [
            'class' => 'btn btn-danger',
            'data' => [
                'confirm' => 'Sei sicuro di voler eliminare questo gruppo?',
                'method' => 'post',
            ],
        ]) ?>
        <?= Html::a('Aggiungi Paziente', ['aggiungi', 'Id' => $model->Id], ['class' => 'btn btn-primary']) ?>
        <?= Html::a('Elimina Paziente', ['elimina', 'Id' => $model->Id], ['class' => 'btn btn-primary']) ?>
    </p>

    <?= DetailView::widget([
        'model' => $model,
        'attributes' => [
            'Id',
            'note',
        ],
    ]) ?>
 

<p>
Pazienti:
</p>
<?= GridView::widget([
        'dataProvider' => $dataProvider,
        'filterModel' => $searchModel,
        'columns' => [
            ['class' => 'yii\grid\SerialColumn'],

            'cf',
            'cf_care',
            'nome',
            'cognome',
          
        ],
    ]); ?>

</div>
