<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "terapia".
 *
 * @property int $Id
 * @property string|null $cf_logo
 * @property string|null $cf_care
 * @property string|null $cf_paz
 * @property string|null $note
 *
 * @property Caregiver $cfCare
 * @property Logopedista $cfLogo
 * @property Paziente $cfPaz
 */
class Terapia extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'terapia';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
			[['cf_logo','cf_paz','cf_care'],'required'],
			//[['cf_logo','cf_paz','cf_care'], 'unique'],
            [['cf_logo', 'cf_care', 'cf_paz'], 'string', 'max' => 16],
            [['note'], 'string', 'max' => 255],
            [['cf_logo'], 'exist', 'skipOnError' => true,'targetClass' => Logopedista::className(), 'targetAttribute' => ['cf_logo' => 'cf']],
            [['cf_care'], 'exist', 'skipOnError' => true, 'targetClass' => Caregiver::className(), 'targetAttribute' => ['cf_care' => 'cf']],
            [['cf_paz'], 'exist', 'skipOnError' => true, 'targetClass' => Paziente::className(), 'targetAttribute' => ['cf_paz' => 'cf']],
        ];
    }

   /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'Id' => 'ID',
            'cf_logo' => 'Codice fiscale Logopedista',
            'cf_care' => 'Codice fiscale  Caregiver',
            'cf_paz' => 'Codice fiscale Paziente',
            'note' => 'Note',
        ];
    } 

    /**
     * Gets query for [[CfCare]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getCfCare()
    {
        return $this->hasOne(Caregiver::className(), ['cf' => 'cf_care']);
    }

    /**
     * Gets query for [[CfLogo]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getCfLogo()
    {
        return $this->hasOne(Logopedista::className(), ['cf' => 'cf_logo']);
    }

    /**
     * Gets query for [[CfPaz]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getCfPaz()
    {
        return $this->hasOne(Paziente::className(), ['cf' => 'cf_paz']);
    }
}
