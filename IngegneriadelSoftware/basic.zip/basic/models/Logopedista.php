<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "logopedista".
 *
 * @property string $cf
 * @property int $id
 * @property string $nome
 * @property string $cognome
 * @property string $email
 *
 * @property TblUser $id0
 */
class Logopedista extends \yii\db\ActiveRecord
{
	
    /**
     * {@inheritdoc}
     */
	public $username;
	public $password;
	
    public static function tableName()
    {
        return 'logopedista';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['cf', 'id', 'nome', 'cognome', 'email'], 'required'],
            [['id'], 'integer'],
			['email', 'email'],
            [['cf'], 'string', 'max' => 16],
            [['nome', 'cognome', 'email'], 'string', 'max' => 32],
            [['email'], 'unique', 'targetClass' => 'app\models\Logopedista', 'message' => 'Questa e-mail è stata già scelta.'],
            [['cf'], 'unique', 'targetClass' => 'app\models\Logopedista', 'message' => 'Questo codice fiscale è stato già registrato.'],
            [['id'], 'exist', 'skipOnError' => true, 'targetClass' => User::className(), 'targetAttribute' => ['id' => 'id']],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'cf' => 'Codice fiscale',
            'id' => 'ID',
            'nome' => 'Nome',
            'cognome' => 'Cognome',
            'email' => 'Email',
        ];
    }

    /**
     * Gets query for [[Id0]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getId0()
    {
        return $this->hasOne(User::className(), ['id' => 'id']);
    }
}
