<?php

use yii\helpers\Html;
use yii\widgets\DetailView;

/* @var $this yii\web\View */
/* @var $model app\models\Prenotazione */

$this->title = $model->Id;
$this->params['breadcrumbs'][] = ['label' => 'Prenotazione', 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
\yii\web\YiiAsset::register($this);
?>
<div class="prenotazione-view">

    <h1><?= Html::encode($this->title) ?></h1>

    <p>
        <?= Html::a('Elimina', ['delete', 'Id' => $model->Id], [
            'class' => 'btn btn-danger',
            'data' => [
                'confirm' => 'Sei sicuro di voler eliminare questa prenotazione?',
                'method' => 'post',
            ],
        ]) ?>
    </p>

    <?= DetailView::widget([
        'model' => $model,
        'attributes' => [
            'Id',
            'dat',
            'cf_logo',
            'cf_care',
        ],
    ]) ?>

</div>
