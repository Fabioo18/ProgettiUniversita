<?php

use yii\helpers\Html;

/* @var $this yii\web\View */
/* @var $model app\models\Appuntamento */

$this->title = 'Aggiorna Appuntamento ';
$this->params['breadcrumbs'][] = ['label' => 'Appuntamento', 'url' => ['index']];
$this->params['breadcrumbs'][] = 'Update';
?>
<div class="appuntamento-update">

    <h1><?= Html::encode($this->title) ?></h1>

    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>

</div>
