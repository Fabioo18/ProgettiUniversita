<?php

namespace app\controllers;

use app\models\Esercizio;
use app\models\EsercizioSearch;
use app\models\EsercizioSearch2;
use yii\web\Controller;
use yii\db\Query;
use yii\web\NotFoundHttpException;
use yii\filters\VerbFilter;
use yii\web\UploadedFile;


/**
 * EsercizioController implements the CRUD actions for Esercizio model.
 */
class EsercizioController extends Controller
{
    /**
     * @inheritDoc
     */
    public function behaviors()
    {
        return array_merge(
            parent::behaviors(),
            [
                'verbs' => [
                    'class' => VerbFilter::className(),
                    'actions' => [
                        'delete' => ['POST'],
                    ],
                ],
            ]
        );
    }

    /**
     * Lists all Esercizio models.
     *
     * @return string
     */
    public function actionIndex()
    {
        $searchModel = new EsercizioSearch();
        $dataProvider = $searchModel->search($this->request->queryParams);

        return $this->render('index', [
            'searchModel' => $searchModel,
            'dataProvider' => $dataProvider,
        ]);
    }
	
	public function actionIndexpaziente()
    {
        $searchModel = new EsercizioSearch2();
        $dataProvider = $searchModel->search($this->request->queryParams);

        return $this->render('indexpaziente', [
            'searchModel' => $searchModel,
            'dataProvider' => $dataProvider,
        ]);
    }
	
	
	public function actionUpload()
    {
		$model = new Esercizio();
		
        if (\Yii::$app->request->isPost && $model->load($this->request->post())) 
        {
            $model->files = UploadedFile::getInstance($model, 'files');

            if ($model->upload()) 
            {
                return $this->redirect(['view', 'Id' => $model->Id]);
            }
        }

		return $this->render('upload', ['model' => $model]);
    }
	
	public function actionUpload2($Id)
    {
		$model = $this->findModel($Id);
		
        if (\Yii::$app->request->isPost && $model->load($this->request->post())) 
        {
            $model->files = UploadedFile::getInstance($model, 'files');

            if ($model->upload2()) 
            {
                return $this->redirect(['indexpaziente']);
            }
        }

		return $this->render('upload2', ['model' => $model]);
    }
	
	public function actionSalta($Id)
	{
		$model = $this->findModel($Id);
		if($model->svolto === 'Sì')
		{
			\Yii::$app->session->setFlash('error', "Impossibile saltare un esercizio già svolto.");
			return $this->redirect(['viewpaziente', 'Id' => $model->Id]);	
		}
		else
		{
			$model->saltato = 'Sì';
			if($model->save())
			{
				\Yii::$app->session->setFlash('success', "Esercizio saltato con successo.");
				return $this->redirect(['indexpaziente']);
			}	
		}
		
	}

    /**
     * Displays a single Esercizio model.
     * @param int $Id ID
     * @return string
     * @throws NotFoundHttpException if the model cannot be found
     */
    public function actionView($Id)
    {
        return $this->render('view', [
            'model' => $this->findModel($Id),
        ]);
    }
	
	public function actionViewpaziente($Id)
    {
		$model = $this->findModel($Id);
		if ($this->request->isPost) 
		{
            if ($model->load($this->request->post()) && $model->save()) 
			{
                return $this->redirect(['viewpaziente', 'Id' => $model->Id]);
            }
        } 
        return $this->render('viewpaziente', ['model' => $model,]);
		
		
    }
	
	public function actionDownload($Id)
	{
		$model = $this->findModel($Id);
		return \Yii::$app->response->sendFile('uploads/singolo/'.$model->nome_file);
	}
	
	public function actionDownload2($Id)
	{
		$model = $this->findModel($Id);
		return \Yii::$app->response->sendFile('uploads/singolo/'.$model->nome_file2);
	}
    /**
     * Creates a new Esercizio model.
     * If creation is successful, the browser will be redirected to the 'view' page.
     * @return string|\yii\web\Response
     */
    public function actionCreate()
    {
        $model = new Esercizio();

        if ($this->request->isPost) 
		{
            if ($model->load($this->request->post()) && $model->save()) 
			{
                return $this->redirect(['view', 'Id' => $model->Id]);
            }
        } 
		else 
		{
            $model->loadDefaultValues();
        }

        return $this->render('create', [
            'model' => $model,
        ]);
    }

    /**
     * Updates an existing Esercizio model.
     * If update is successful, the browser will be redirected to the 'view' page.
     * @param int $Id ID
     * @return string|\yii\web\Response
     * @throws NotFoundHttpException if the model cannot be found
     */
    public function actionUpdate($Id)
    {
        $model = $this->findModel($Id);

        if ($this->request->isPost && $model->load($this->request->post()) && $model->save()) {
            return $this->redirect(['view', 'Id' => $model->Id]);
        }

        return $this->render('update', [
            'model' => $model,
        ]);
    }

    /**
     * Deletes an existing Esercizio model.
     * If deletion is successful, the browser will be redirected to the 'index' page.
     * @param int $Id ID
     * @return \yii\web\Response
     * @throws NotFoundHttpException if the model cannot be found
     */
    public function actionDelete($Id)
    {
        $model = $this->findModel($Id);
		unlink(\Yii::$app->basePath . '\web\uploads\singolo/'.$model->nome_file);
		if($model->nome_file2 !== null)
		{
			unlink(\Yii::$app->basePath . '\web\uploads\singolo/'.$model->nome_file2);
		}
		$model->delete();

        return $this->redirect(['index']);
    }

    /**
     * Finds the Esercizio model based on its primary key value.
     * If the model is not found, a 404 HTTP exception will be thrown.
     * @param int $Id ID
     * @return Esercizio the loaded model
     * @throws NotFoundHttpException if the model cannot be found
     */
    protected function findModel($Id)
    {
        if (($model = Esercizio::findOne(['Id' => $Id])) !== null) {
            return $model;
        }

        throw new NotFoundHttpException('The requested page does not exist.');
    }
}
