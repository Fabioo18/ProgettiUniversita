<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;

/* @var $this yii\web\View */
/* @var $model app\models\Terapia */
/* @var $form yii\widgets\ActiveForm */
?>

<div class="terapia-form">

    <?php $form = ActiveForm::begin(); ?>
	
	<?php
	if(Yii::$app->session->hasFlash('error'))
	{
	?>
		<div class="alert alert-error">
			<?php echo Yii::$app->session->getFlash('error');?>
		<div/>
	<?php
	}
	?>

    <?= $form->field($model, 'cf_logo')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'cf_care')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'cf_paz')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'note')->textInput(['maxlength' => true]) ?>

    <div class="form-group">
        <?= Html::submitButton('Save', ['class' => 'btn btn-success']) ?>
    </div>

    <?php ActiveForm::end(); ?>

</div>
