<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "tbl_user".
 *
 * @property int $id
 * @property string $username
 * @property string $pass
 * @property string|null $authKey
 * @property string|null $accessToken
 * @property string|null $categoria
 *
 * @property Caregiver[] $caregivers
 * @property Logopedista[] $logopedistas
 * @property Paziente[] $pazientes
 */
class User extends \yii\db\ActiveRecord implements \yii\web\IdentityInterface
{
    /**
     * {@inheritdoc}
     */
	public $rawPassword;
	public $nome;
	public $cognome;
	public $codice_fiscale;
	public $email;
	 
    public static function tableName()
    {
        return 'tbl_user';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [		
            [['username', 'pass','rawPassword','nome','cognome','codice_fiscale','email','categoria'], 'required'],
            [['username'], 'string', 'max' => 32],
            [['pass', 'authKey', 'accessToken'], 'string', 'max' => 128],
            [['username'], 'unique', 'targetClass' => 'app\models\User', 'message' => 'Questo username è stato già scelto.'],
			[['username', 'pass', 'rawPassword', 'authKey', 'accessToken'], 'safe']
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'username' => 'Username',
            'pass' => 'Pass',
            'authKey' => 'Auth Key',
			'rawPassword' => 'Password',
            'accessToken' => 'Access Token',
            'categoria' => 'Categoria',
        ];
    }

    /**
     * Gets query for [[Caregivers]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getCaregivers()
    {
        return $this->hasMany(Caregiver::className(), ['id' => 'id']);
    }

    /**
     * Gets query for [[Logopedistas]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getLogopedistas()
    {
        return $this->hasMany(Logopedista::className(), ['id' => 'id']);
    }

    /**
     * Gets query for [[Pazientes]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getPazientes()
    {
        return $this->hasMany(Paziente::className(), ['id' => 'id']);
    }
	
	public function getAuthKey()
	{
		return $this->authKey;
	}
	
	public function getId()
	{
		return $this->id;
	}
	
	public static function findIdentity($id)
	{
		return static::findOne(['id' =>$id]);
	}
	
	public static function findIdentityByAccessToken($token, $type = null)
	{
		return static::findOne(['successToken' -> $token]);
	}
	
	public function ValidateAuthKey($authKey)
	{
		return $this->authKey === $authKey;
	}
	
	public function setPassword($password)
	{
		$this->pass = \Yii::$app->security->generatePasswordHash($password);
	}
	
	public function setUsername($username)
	{
		$this->username = $username;
	}
	
	public function getPassword()
    {
        return $this->pass;
    }
	
	public function getCategoria()
    {
        return $this->categoria;
    }
	
	public function generateAuthkey()
	{
		$this->authKey = \Yii::$app->security->generateRandomString();
	}
	
	public function validatePassword($password)
	{
		return \Yii::$app->security->validatePassword($password, $this->pass);
	}
	
	public static function findByUsername($username)
	{
		return static::findOne(['username' => $username]);
	}
	
	public function getPassword2()
	{
		
		return Yii::$app->getSecurity()->decryptByPassword($this->pass, $this->rawPassword);
	}
	
	public function getCf()
	{
		return $this->cf;
	}
}
