<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;

/* @var $this yii\web\View */
/* @var $model app\models\Appuntamento */
/* @var $form yii\widgets\ActiveForm */
?>

<div class="appuntamento-form">

    <?php $form = ActiveForm::begin(); ?>

    <?= $form->field($model, 'cf_logo')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'dat')->textInput() ?>

    <?= $form->field($model, 'note')->textInput(['maxlength' => true]) ?>

    <div class="form-group">
        <?= Html::submitButton('Salva', ['class' => 'btn btn-success']) ?>
    </div>

    <?php ActiveForm::end(); ?>

</div>
