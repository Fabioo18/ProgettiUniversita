<?php

/* @var $this yii\web\View */

$this->title = 'Logopedia System';
?>


<div class="site-index" >

    <div class="jumbotron text-center bg-transparent">
        <h1 class="display-4">Benvenuto !</h1>

        <p class="lead">Logopedia System, per essere vicini ai tuoi cari.</p>

        <p><a class="btn btn-lg btn-success" href="http://www.yiiframework.com">Chi siamo</a></p>
    </div>

</div>
